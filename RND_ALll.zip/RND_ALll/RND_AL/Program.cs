﻿using System;

namespace RND_AL
{
    class Program
    {
        static void Main(string[] args)
        {
            Random vsz = new Random();

            

            int i = vsz.Next(0, 10);

            int a = vsz.Next(0, 10);

            Console.WriteLine("A két szám: " + i + "," + a);

            if(i > a)
            {
                Console.WriteLine("A nagyobb szám: " + i);
            }
            else if (a > i)
            {
                Console.WriteLine("A nagyobb szám: " + a);
            }

            else if(i == a)
            {
                Console.WriteLine("A két szám egyenlő: ");
            }


        }
    }
}
